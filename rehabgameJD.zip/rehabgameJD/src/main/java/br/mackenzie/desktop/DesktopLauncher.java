package br.mackenzie.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import br.mackenzie.game.RehabilitationGame;

public class DesktopLauncher {

    public static void main(String[] args) {
        LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
    config.title = "RehabCycle";
    config.width = 1280;
    config.height = 720;
    // default to windowed to avoid clipping on some displays; presenter can toggle fullscreen if desired
    config.fullscreen = false;
    config.resizable = true;
    config.width = 1280;
    config.height = 720;
        config.vSyncEnabled = true;
        new LwjglApplication(new RehabilitationGame(), config);
    }
}
