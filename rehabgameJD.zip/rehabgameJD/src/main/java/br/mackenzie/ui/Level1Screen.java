package br.mackenzie.ui;

import br.mackenzie.game.RehabilitationGame;

public class Level1Screen extends AbstractLevelScreen {

    public Level1Screen(RehabilitationGame game) {
        super(game,
              1,
              70f,
              20f,
              40f);
    }

    @Override
    protected void updateGameLogic(float delta, float cadence, float normalizedSpeed) {
        // Lógica específica do nível 1 (aquecimento) se quiser adicionar
    }
}
