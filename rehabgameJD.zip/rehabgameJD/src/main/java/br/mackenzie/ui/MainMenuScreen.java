package br.mackenzie.ui;

import br.mackenzie.game.RehabilitationGame;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class MainMenuScreen extends ScreenAdapter {

    private final RehabilitationGame game;
    private final Stage stage;

    private TextButton startButton;
    private TextButton statsButton;
    private TextButton inputModeButton;
    private TextButton quitButton;

    private TextButton[] buttonList;
    private int selectedIndex = 0;

    public MainMenuScreen(RehabilitationGame game) {
        this.game = game;
        this.stage = new Stage(new ScreenViewport());
        createUI();
        Gdx.input.setInputProcessor(stage);
    }

    private void createUI() {
        Table root = new Table();
        root.setFillParent(true);
        root.pad(40f);
        // set background if skin provides it
        try {
            Drawable bg = game.getSkin().getDrawable("glass-panel");
            if (bg != null) root.setBackground(bg);
        } catch (Exception ignored) {
        }
        stage.addActor(root);

    Label title = new Label("RehabCycle", game.getSkin(), "title");
    title.setAlignment(Align.center);
    Label subtitle = new Label("Reabilitação gamificada com bicicleta", game.getSkin(), "subtitle");
        subtitle.setAlignment(Align.center);

        startButton = new TextButton("Iniciar", game.getSkin());
        statsButton = new TextButton("Estatísticas", game.getSkin());
        inputModeButton = new TextButton("Modo: Teclado", game.getSkin());
        quitButton = new TextButton("Sair", game.getSkin(), "danger");

        buttonList = new TextButton[]{startButton, statsButton, inputModeButton, quitButton};

        startButton.addListener(e -> {
            if (startButton.isPressed()) {
                game.setScreen(new LevelSelectScreen(game));
                return true;
            }
            return false;
        });

        statsButton.addListener(e -> {
            if (statsButton.isPressed()) {
                game.setScreen(new StatsScreen(game));
                return true;
            }
            return false;
        });

        inputModeButton.addListener(e -> {
            if (inputModeButton.isPressed()) {
                toggleInputMode();
                return true;
            }
            return false;
        });

        quitButton.addListener(e -> {
            if (quitButton.isPressed()) {
                Gdx.app.exit();
                return true;
            }
            return false;
        });

        root.center();
    root.add(title).padBottom(14f).row();
    root.add(subtitle).padBottom(26f).row();
    root.add(startButton).width(340f).height(64f).padBottom(12f).row();
    root.add(statsButton).width(340f).height(64f).padBottom(12f).row();
    root.add(inputModeButton).width(340f).height(64f).padBottom(12f).row();
    root.add(quitButton).width(340f).height(64f).padBottom(12f).row();

        updateButtonFocus();
    }

    private void toggleInputMode() {
        String text = inputModeButton.getText().toString();
        if (text.contains("Teclado")) {
            game.useArduinoInput();
            inputModeButton.setText("Modo: Arduino");
        } else {
            game.useKeyboardInput();
            inputModeButton.setText("Modo: Teclado");
        }
    }

    private void updateButtonFocus() {
        for (int i = 0; i < buttonList.length; i++) {
            TextButton b = buttonList[i];
            if (i == selectedIndex) {
                // make selected button more visible and slightly larger
                b.setColor(1f, 1f, 1f, 1f);
                try {
                    b.getLabel().setFontScale(1.05f);
                } catch (Exception ignored) {
                }
            } else {
                b.setColor(0.9f, 0.95f, 1f, 0.85f);
                try {
                    b.getLabel().setFontScale(1f);
                } catch (Exception ignored) {
                }
            }
        }
    }

    private void handleKeyboard() {
        if (Gdx.input.isKeyJustPressed(Input.Keys.UP)) {
            selectedIndex = (selectedIndex - 1 + buttonList.length) % buttonList.length;
            updateButtonFocus();
        } else if (Gdx.input.isKeyJustPressed(Input.Keys.DOWN)) {
            selectedIndex = (selectedIndex + 1) % buttonList.length;
            updateButtonFocus();
        }

        if (Gdx.input.isKeyJustPressed(Input.Keys.ENTER) ||
            Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            activateSelected();
        }
    }

    private void activateSelected() {
        switch (selectedIndex) {
            case 0: // Iniciar
                game.setScreen(new LevelSelectScreen(game));
                break;
            case 1: // Estatísticas
                game.setScreen(new StatsScreen(game));
                break;
            case 2: // Modo input
                toggleInputMode();
                break;
            case 3: // Sair
                Gdx.app.exit();
                break;
        }
    }

    @Override
    public void render(float delta) {
        handleKeyboard();

    // slightly brighter background to improve contrast with UI
    Gdx.gl.glClearColor(0.05f, 0.08f, 0.16f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
