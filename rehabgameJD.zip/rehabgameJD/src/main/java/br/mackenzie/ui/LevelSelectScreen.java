package br.mackenzie.ui;

import br.mackenzie.game.GameProgress;
import br.mackenzie.game.RehabilitationGame;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class LevelSelectScreen extends ScreenAdapter {

    private final RehabilitationGame game;
    private final Stage stage;

    private TextButton[] levelButtons;
    private TextButton backButton;
    private int selectedIndex = 0; // 0..3 (3 = voltar)

    public LevelSelectScreen(RehabilitationGame game) {
        this.game = game;
        this.stage = new Stage(new ScreenViewport());
        createUI();
        Gdx.input.setInputProcessor(stage);
    }

    private void createUI() {
        GameProgress progress = game.getProgress();

        Table root = new Table();
        root.setFillParent(true);
        root.pad(40f);
        // set background if skin provides it
        try {
            Drawable bg = game.getSkin().getDrawable("glass-panel");
            if (bg != null) root.setBackground(bg);
        } catch (Exception ignored) {
        }
        stage.addActor(root);

        Label title = new Label("Selecione o nível", game.getSkin(), "title");
        title.setAlignment(Align.center);
        Label subtitle = new Label("Cada nível representa um estágio da reabilitação.", game.getSkin(), "subtitle");
        subtitle.setAlignment(Align.center);

        TextButton level1 = new TextButton("Nível 1 · Aquecimento", game.getSkin());
        TextButton level2 = new TextButton("Nível 2 · Resistência", game.getSkin());
        TextButton level3 = new TextButton("Nível 3 · Intervalos", game.getSkin());
        backButton = new TextButton("Voltar", game.getSkin());

        levelButtons = new TextButton[]{level1, level2, level3};

        for (int i = 0; i < levelButtons.length; i++) {
            boolean unlocked = progress.isLevelUnlocked(i + 1);
            levelButtons[i].setDisabled(!unlocked);
            if (!unlocked) {
                levelButtons[i].setText(levelButtons[i].getText() + " · 🔒");
            }
        }

        level1.addListener(e -> {
            if (level1.isPressed() && progress.isLevelUnlocked(1)) {
                game.setScreen(new Level1Screen(game));
                return true;
            }
            return false;
        });

        level2.addListener(e -> {
            if (level2.isPressed() && progress.isLevelUnlocked(2)) {
                game.setScreen(new Level2Screen(game));
                return true;
            }
            return false;
        });

        level3.addListener(e -> {
            if (level3.isPressed() && progress.isLevelUnlocked(3)) {
                game.setScreen(new Level3Screen(game));
                return true;
            }
            return false;
        });

        backButton.addListener(e -> {
            if (backButton.isPressed()) {
                game.setScreen(new MainMenuScreen(game));
                return true;
            }
            return false;
        });

        root.center();
    root.add(title).padBottom(14f).row();
    root.add(subtitle).padBottom(26f).row();
    root.add(level1).width(340f).height(64f).padBottom(12f).row();
    root.add(level2).width(340f).height(64f).padBottom(12f).row();
    root.add(level3).width(340f).height(64f).padBottom(18f).row();
    root.add(backButton).width(260f).height(56f).row();

        updateFocus();
    }

    private void updateFocus() {
        for (int i = 0; i < levelButtons.length; i++) {
            TextButton b = levelButtons[i];
            if (selectedIndex == i) {
                b.setColor(1f, 1f, 1f, 1f);
                try { b.getLabel().setFontScale(1.05f); } catch (Exception ignored) {}
            } else {
                b.setColor(0.9f, 0.95f, 1f, 0.85f);
                try { b.getLabel().setFontScale(1f); } catch (Exception ignored) {}
            }
        }
        if (selectedIndex == 3) {
            backButton.setColor(1f, 1f, 1f, 1f);
            try { backButton.getLabel().setFontScale(1.05f); } catch (Exception ignored) {}
        } else {
            backButton.setColor(0.9f, 0.95f, 1f, 0.85f);
            try { backButton.getLabel().setFontScale(1f); } catch (Exception ignored) {}
        }
    }

    private void handleKeyboard() {
        int maxIndex = 3;

        if (Gdx.input.isKeyJustPressed(Input.Keys.UP)) {
            selectedIndex = (selectedIndex - 1 + (maxIndex + 1)) % (maxIndex + 1);
            updateFocus();
        } else if (Gdx.input.isKeyJustPressed(Input.Keys.DOWN)) {
            selectedIndex = (selectedIndex + 1) % (maxIndex + 1);
            updateFocus();
        }

        if (Gdx.input.isKeyJustPressed(Input.Keys.ENTER) ||
            Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            activateSelected();
        }

        if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
            game.setScreen(new MainMenuScreen(game));
        }
    }

    private void activateSelected() {
        switch (selectedIndex) {
            case 0:
                if (!levelButtons[0].isDisabled()) {
                    game.setScreen(new Level1Screen(game));
                }
                break;
            case 1:
                if (!levelButtons[1].isDisabled()) {
                    game.setScreen(new Level2Screen(game));
                }
                break;
            case 2:
                if (!levelButtons[2].isDisabled()) {
                    game.setScreen(new Level3Screen(game));
                }
                break;
            case 3:
                game.setScreen(new MainMenuScreen(game));
                break;
        }
    }

    @Override
    public void render(float delta) {
        handleKeyboard();

        // slightly brighter background for contrast
        Gdx.gl.glClearColor(0.05f, 0.08f, 0.16f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
