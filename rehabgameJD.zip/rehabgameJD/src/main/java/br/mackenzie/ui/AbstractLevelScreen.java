package br.mackenzie.ui;

import br.mackenzie.game.BikeInput;
import br.mackenzie.game.GameProgress;
import br.mackenzie.game.RehabilitationGame;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ProgressBar;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public abstract class AbstractLevelScreen extends ScreenAdapter {

    protected final RehabilitationGame game;
    protected final Stage stage; // world stage (camera follows player)
    private final Stage uiStage; // fixed UI stage
    protected final BikeInput bikeInput;
    protected final GameProgress progress;

    protected float elapsedTime;
    protected float duration;
    protected float targetMinCadence;
    protected float targetMaxCadence;

    protected float timeInTargetZone;
    protected float sumCadence;
    protected int cadenceSamples;

    protected int levelNumber;
    protected float distance;
    protected float distanceGoal;

    private Label titleLabel;
    private Label timeLabel;
    private Label cadenceLabel;
    private Label hintLabel;
    private ProgressBar cadenceBar;
    private Label scoreLabel;
    private Label distanceLabel;
    private ProgressBar distanceBar;
    private ProgressBar staminaBar;
    private float stamina = 100f;
    private final float maxStamina = 100f;
    private boolean defeated = false;
    // simple player visual / animated sprite support
    private Texture playerTexture;
    private Image playerImage;
    private Animation<TextureRegion> playerAnimation;
    private Animation<TextureRegion> runAnimation;
    private Animation<TextureRegion> jumpAnimation;
    private float playerAnimTime = 0f;
    private java.util.List<Texture> playerFrames = new java.util.ArrayList<>();
    private float playerX;
    private float playerY;
    private float playerSpeedFactor = 300f; // pixels per normalized speed unit
    // background layers for parallax / camera-follow
    private Image bgFar;
    private Image bgMid;
    private Image bgNear;
    private Image fullBg;
    private java.util.List<Image> bgFarTiles = new java.util.ArrayList<>();
    private java.util.List<Image> bgMidTiles = new java.util.ArrayList<>();
    private java.util.List<Image> bgNearTiles = new java.util.ArrayList<>();
    private com.badlogic.gdx.graphics.Texture bgFarTex;
    private com.badlogic.gdx.graphics.Texture bgMidTex;
    private com.badlogic.gdx.graphics.Texture bgNearTex;
    // jump physics
    private boolean isJumping = false;
    private float jumpVelocity = 0f;
    private float groundY = 80f;
    private float gravity = -1500f;
    // collectibles and scoring
    private java.util.List<Image> collectibles;
    private float spawnTimer;
    private float spawnInterval = 2.0f;
    // tunable spawn interval components (min + random*range)
    protected float spawnIntervalMin = 1.2f;
    protected float spawnIntervalRange = 2.0f;
    private int score;
    private float bonusThreshold = 0.85f; // normalized speed to get bonus
    private int bonusMultiplier = 2;

    public AbstractLevelScreen(RehabilitationGame game,
                               int levelNumber,
                               float duration,
                               float targetMinCadence,
                               float targetMaxCadence) {
        this.game = game;
        this.levelNumber = levelNumber;
        this.duration = duration;
        this.targetMinCadence = targetMinCadence;
        this.targetMaxCadence = targetMaxCadence;

    this.stage = new Stage(new ScreenViewport());
    this.uiStage = new Stage(new ScreenViewport());
        this.bikeInput = game.getBikeInput();
        this.progress = game.getProgress();

        createUI();
        // distance goal proportional to duration (approximate)
        this.distance = 0f;
        this.distanceGoal = duration * 10f;
        // UI should receive input first, then world
        InputMultiplexer im = new InputMultiplexer();
        im.addProcessor(uiStage);
        im.addProcessor(stage);
        Gdx.input.setInputProcessor(im);
    }

    /**
     * Adjust collectible spawn timing for subclasses.
     * @param min base minimum seconds between spawns
     * @param range random range to add on top of min
     */
    protected void setSpawnInterval(float min, float range) {
        this.spawnIntervalMin = Math.max(0.1f, min);
        this.spawnIntervalRange = Math.max(0f, range);
    }

    private void createUI() {
        // ensure viewport matches actual window size (fix fullscreen behavior when switching screens)
        try {
            stage.getViewport().update(com.badlogic.gdx.Gdx.graphics.getWidth(), com.badlogic.gdx.Gdx.graphics.getHeight(), true);
        } catch (Exception ignored) {}
        // try to load per-level background (one image per level); fall back to parallax layers
        try {
            String perLevel = null;
            if (levelNumber == 1) perLevel = "backgroundimagelevel1";
            else if (levelNumber == 2) perLevel = "backgroundimagelevel2";
            else if (levelNumber == 3) perLevel = "backgroundlevel3";
            com.badlogic.gdx.files.FileHandle per = null;
            if (perLevel != null) per = findBackground(perLevel);
            if (per != null) {
                fullBg = new Image(new Texture(per));
                // stretch to viewport size
                float vw = stage.getViewport().getWorldWidth();
                float vh = stage.getViewport().getWorldHeight();
                fullBg.setSize(vw, vh);
                fullBg.setPosition(0, 0);
                stage.addActor(fullBg);
            } else {
                com.badlogic.gdx.files.FileHandle fhFar = findBackground("bg_far");
                    if (fhFar != null) {
                        bgFarTex = new Texture(fhFar);
                        float tileW = bgFarTex.getWidth();
                        float tileH = bgFarTex.getHeight();
                        int tiles = 50; // cover a wide horizontal span for demo
                        for (int i = 0; i < tiles; i++) {
                            Image t = new Image(bgFarTex);
                            t.setPosition(i * tileW, stage.getViewport().getWorldHeight() - tileH);
                            bgFarTiles.add(t);
                            stage.addActor(t);
                        }
                    }
                com.badlogic.gdx.files.FileHandle fhMid = findBackground("bg_mid");
                    if (fhMid != null) {
                        bgMidTex = new Texture(fhMid);
                        float tileW = bgMidTex.getWidth();
                        float tileH = bgMidTex.getHeight();
                        int tiles = 50;
                        for (int i = 0; i < tiles; i++) {
                            Image t = new Image(bgMidTex);
                            t.setPosition(i * tileW, stage.getViewport().getWorldHeight() - tileH - 80);
                            bgMidTiles.add(t);
                            stage.addActor(t);
                        }
                    }
                com.badlogic.gdx.files.FileHandle fhNear = findBackground("bg_near");
                    if (fhNear != null) {
                        bgNearTex = new Texture(fhNear);
                        float tileW = bgNearTex.getWidth();
                        float tileH = bgNearTex.getHeight();
                        int tiles = 50;
                        for (int i = 0; i < tiles; i++) {
                            Image t = new Image(bgNearTex);
                            t.setPosition(i * tileW, 0);
                            bgNearTiles.add(t);
                            stage.addActor(t);
                        }
                    }
            }
        } catch (Exception ignored) {
        }

        Table root = new Table();
        root.setFillParent(true);
        root.pad(40f);
        // set background if skin provides it
        try {
            Drawable bg = game.getSkin().getDrawable("glass-panel");
            if (bg != null) root.setBackground(bg);
        } catch (Exception ignored) {
        }
        uiStage.addActor(root); // UI placed on uiStage so it stays fixed

        titleLabel = new Label("Nível " + levelNumber, game.getSkin(), "title");
        timeLabel = new Label("Tempo: 0s", game.getSkin());
        cadenceLabel = new Label("Cadência: 0 rpm", game.getSkin());
        hintLabel = new Label("Pedale para manter a cadência na zona alvo.", game.getSkin(), "subtitle");
        cadenceBar = new ProgressBar(0f, 1f, 0.01f, false, game.getSkin(), "default-horizontal");

        root.top().left();
    root.add(titleLabel).left().padBottom(10f).row();
    root.add(timeLabel).left().padBottom(10f).row();
    root.add(cadenceLabel).left().padBottom(10f).row();
        root.add(cadenceBar).width(400f).padBottom(10f).row();
        distanceLabel = new Label("Distância: 0 m / 0 m", game.getSkin());
        distanceBar = new ProgressBar(0f, 1f, 0.01f, false, game.getSkin(), "default-horizontal");
    scoreLabel = new Label("Pontos: 0", game.getSkin());
        root.add(distanceLabel).left().padBottom(6f).row();
        root.add(distanceBar).width(400f).padBottom(25f).row();
        // HUD: top-right small panel for score and stamina
        Table hud = new Table();
        hud.top().right();
        hud.setFillParent(true);
        hud.pad(16f);
        try {
            Drawable panel = game.getSkin().getDrawable("glass-panel");
            if (panel != null) hud.setBackground(panel);
        } catch (Exception ignored) {}
        staminaBar = new ProgressBar(0f, 1f, 0.01f, false, game.getSkin(), "default-horizontal");
        staminaBar.setValue(stamina / maxStamina);
        hud.add(scoreLabel).right().padBottom(8f).row();
        hud.add(staminaBar).width(200f).row();
        uiStage.addActor(hud);
        root.add(hintLabel).left().row();

        // create or load a player image or animation (prefer frames under assets/images/player/)
        try {
            com.badlogic.gdx.files.FileHandle framesDir = com.badlogic.gdx.Gdx.files.local("assets/images/player");
            if (framesDir.exists() && framesDir.isDirectory()) {
                com.badlogic.gdx.files.FileHandle[] files = framesDir.list();
                java.util.Arrays.sort(files, new java.util.Comparator<com.badlogic.gdx.files.FileHandle>() {
                    @Override
                    public int compare(com.badlogic.gdx.files.FileHandle a, com.badlogic.gdx.files.FileHandle b) {
                        return a.name().compareTo(b.name());
                    }
                });
                java.util.List<TextureRegion> runRegions = new java.util.ArrayList<>();
                java.util.List<TextureRegion> jumpRegions = new java.util.ArrayList<>();
                for (com.badlogic.gdx.files.FileHandle fh : files) {
                    String n = fh.name().toLowerCase();
                    if (n.endsWith(".png") || n.endsWith(".jpg")) {
                        try {
                            Texture t = new Texture(fh);
                            playerFrames.add(t);
                            TextureRegion tr = new TextureRegion(t);
                            if (n.startsWith("run") || n.contains("run")) runRegions.add(tr);
                            else if (n.startsWith("jump") || n.contains("jump")) jumpRegions.add(tr);
                            else runRegions.add(tr);
                        } catch (Exception ignored) {
                        }
                    }
                }
                if (!runRegions.isEmpty()) {
                    runAnimation = new Animation<TextureRegion>(1f / 12f, runRegions.toArray(new TextureRegion[0]));
                }
                if (!jumpRegions.isEmpty()) {
                    jumpAnimation = new Animation<TextureRegion>(1f / 12f, jumpRegions.toArray(new TextureRegion[0]));
                }
                if (runAnimation != null) {
                    playerAnimTime = 0f;
                    playerAnimation = runAnimation;
                    playerImage = new Image(new TextureRegionDrawable(playerAnimation.getKeyFrame(0f)));
                }
                // if the player folder had no frames, try to use Run*.png / run*.png in assets/images
                if (runAnimation == null && jumpAnimation == null) {
                    com.badlogic.gdx.files.FileHandle imagesDir = com.badlogic.gdx.Gdx.files.local("assets/images");
                    if (imagesDir.exists() && imagesDir.isDirectory()) {
                        com.badlogic.gdx.files.FileHandle[] all = imagesDir.list();
                        java.util.Arrays.sort(all, new java.util.Comparator<com.badlogic.gdx.files.FileHandle>() {
                            @Override
                            public int compare(com.badlogic.gdx.files.FileHandle a, com.badlogic.gdx.files.FileHandle b) {
                                return a.name().compareTo(b.name());
                            }
                        });
                        java.util.List<TextureRegion> runRegions2 = new java.util.ArrayList<>();
                        java.util.List<TextureRegion> jumpRegions2 = new java.util.ArrayList<>();
                        for (com.badlogic.gdx.files.FileHandle fh : all) {
                            String n = fh.name().toLowerCase();
                            if (n.matches("run\\d+\\.(png|jpg|jpeg)$")) {
                                try {
                                    Texture t = new Texture(fh);
                                    playerFrames.add(t);
                                    runRegions2.add(new TextureRegion(t));
                                } catch (Exception ignored) {
                                }
                            } else if (n.matches("jump\\d+\\.(png|jpg|jpeg)$")) {
                                try {
                                    Texture t = new Texture(fh);
                                    playerFrames.add(t);
                                    jumpRegions2.add(new TextureRegion(t));
                                } catch (Exception ignored) {
                                }
                            }
                        }
                        if (!runRegions2.isEmpty()) {
                            runAnimation = new Animation<TextureRegion>(1f / 12f, runRegions2.toArray(new TextureRegion[0]));
                        }
                        if (!jumpRegions2.isEmpty()) {
                            jumpAnimation = new Animation<TextureRegion>(1f / 12f, jumpRegions2.toArray(new TextureRegion[0]));
                        }
                        if (runAnimation != null) {
                            playerAnimation = runAnimation;
                            playerAnimTime = 0f;
                            playerImage = new Image(new TextureRegionDrawable(playerAnimation.getKeyFrame(0f)));
                        }
                    }
                }
            }

            // fallback: single texture file
            if (playerImage == null) {
                if (com.badlogic.gdx.Gdx.files.local("assets/images/player_run.png").exists()) {
                    playerTexture = new com.badlogic.gdx.graphics.Texture(com.badlogic.gdx.Gdx.files.local("assets/images/player_run.png"));
                } else {
                    Pixmap p = new Pixmap(48, 32, Pixmap.Format.RGBA8888);
                    p.setColor(0.2f, 0.7f, 1f, 1f);
                    p.fill();
                    playerTexture = new Texture(p);
                    p.dispose();
                }
                playerImage = new Image(playerTexture);
            }
        } catch (Exception e) {
            Pixmap p = new Pixmap(48, 32, Pixmap.Format.RGBA8888);
            p.setColor(0.2f, 0.7f, 1f, 1f);
            p.fill();
            playerTexture = new Texture(p);
            p.dispose();
            playerImage = new Image(playerTexture);
        }
    // initial position at left side (a bit left of center), near bottom
    playerX = Math.max(100f, stage.getViewport().getWorldWidth() * 0.25f);
    // compute groundY relative to viewport
    float vw = stage.getViewport().getWorldWidth();
    float vh = stage.getViewport().getWorldHeight();
    groundY = Math.max(40f, vh * 0.12f);
    playerY = groundY;
    // scale player to reasonable size relative to viewport
    try {
        if (playerImage.getDrawable() instanceof TextureRegionDrawable) {
            TextureRegionRegionHelper: {
            }
            TextureRegion tr = ((TextureRegionDrawable) playerImage.getDrawable()).getRegion();
            float ph = tr.getRegionHeight();
            float pw = tr.getRegionWidth();
            float desiredH = vh * 0.20f; // 20% of screen height
            float scale = desiredH / ph;
            playerImage.setSize(pw * scale, ph * scale);
        }
    } catch (Exception ignored) {
    }
    playerImage.setPosition(playerX, playerY);
    stage.addActor(playerImage); // world actor
        // collectibles
        collectibles = new java.util.ArrayList<>();
        spawnTimer = 0f;
        score = 0;
    }

    @Override
    public void render(float delta) {
        // allow quick return to main menu
        if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
            game.setScreen(new br.mackenzie.ui.MainMenuScreen(game));
            return;
        }
        bikeInput.update(delta);

        float cadence = bikeInput.getCadence();
        float normalized = bikeInput.getNormalizedSpeed();

        elapsedTime += delta;
        sumCadence += cadence;
        cadenceSamples++;

        if (cadence >= targetMinCadence && cadence <= targetMaxCadence) {
            timeInTargetZone += delta;
        }

        timeLabel.setText(String.format("Tempo: %.0f s / %.0f s", elapsedTime, duration));
    cadenceLabel.setText(String.format("Cadência: %.0f rpm (Alvo: %.0f–%.0f)",
        cadence, targetMinCadence, targetMaxCadence));
    cadenceBar.setValue(normalized);

        // update player animation and position proportional to normalized speed
    if (playerImage != null) {
        // jump trigger: keyboard uses SPACE key, Arduino (or other inputs) can be automatic by cadence
        float jumpTriggerThreshold = 0.85f;
        boolean keyboardMode = (bikeInput instanceof br.mackenzie.game.KeyboardBikeInput);
        if (!isJumping) {
            if (keyboardMode) {
                if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
                    isJumping = true;
                    jumpVelocity = 700f * Math.max(0.6f, normalized);
                    playerAnimTime = 0f;
                }
            } else {
                if (normalized >= jumpTriggerThreshold) {
                    isJumping = true;
                    // initial jump impulse scaled by normalized speed
                    jumpVelocity = 700f * normalized;
                    playerAnimTime = 0f; // restart animation timing for jump
                }
            }
        }

        // update jump physics
        if (isJumping) {
            jumpVelocity += gravity * delta;
            playerY += jumpVelocity * delta;
            if (playerY <= groundY) {
                playerY = groundY;
                isJumping = false;
                jumpVelocity = 0f;
                playerAnimTime = 0f;
            }
        }

        // select appropriate animation
        Animation<TextureRegion> currentAnim = null;
        if (isJumping && jumpAnimation != null) currentAnim = jumpAnimation;
        else if (runAnimation != null) currentAnim = runAnimation;
        else currentAnim = playerAnimation;

    if (currentAnim != null) {
            float speedFactor = isJumping ? 1f : (0.5f + normalized * 3f);
            playerAnimTime += delta * speedFactor;
            TextureRegion frame = currentAnim.getKeyFrame(playerAnimTime, !isJumping);
            playerImage.setDrawable(new TextureRegionDrawable(frame));
            // preserve scaled size after changing drawable
            try {
                float vh2 = stage.getViewport().getWorldHeight();
                TextureRegion tr = ((TextureRegionDrawable) playerImage.getDrawable()).getRegion();
                float desiredH = vh2 * 0.20f;
                float scale = desiredH / tr.getRegionHeight();
                playerImage.setSize(tr.getRegionWidth() * scale, tr.getRegionHeight() * scale);
            } catch (Exception ignored) {
            }
        }

    float move = normalized * playerSpeedFactor * delta;
    playerX += move;
    // update camera to follow the player (put player slightly left of center)
    float vw = stage.getViewport().getWorldWidth();
    com.badlogic.gdx.graphics.Camera cam = stage.getCamera();
    float targetCamX = playerX + vw * 0.35f;
    cam.position.x = targetCamX;
    cam.update();
        // update parallax backgrounds to track camera (move slower than foreground)
        float camLeft = cam.position.x - vw * 0.5f;
        if (fullBg != null) {
            fullBg.setX(camLeft);
        }
        // far layer (slow)
        if (bgFarTex != null && !bgFarTiles.isEmpty()) {
            float tileW = bgFarTex.getWidth();
            float parallax = 0.35f;
            for (int i = 0; i < bgFarTiles.size(); i++) {
                Image t = bgFarTiles.get(i);
                float baseX = i * tileW;
                t.setX(baseX + camLeft * (1 - parallax));
            }
        }
        if (bgMidTex != null && !bgMidTiles.isEmpty()) {
            float tileW = bgMidTex.getWidth();
            float parallax = 0.6f;
            for (int i = 0; i < bgMidTiles.size(); i++) {
                Image t = bgMidTiles.get(i);
                float baseX = i * tileW;
                t.setX(baseX + camLeft * (1 - parallax));
            }
        }
        if (bgNearTex != null && !bgNearTiles.isEmpty()) {
            float tileW = bgNearTex.getWidth();
            float parallax = 0.85f;
            for (int i = 0; i < bgNearTiles.size(); i++) {
                Image t = bgNearTiles.get(i);
                float baseX = i * tileW;
                t.setX(baseX + camLeft * (1 - parallax));
            }
        }
    // position player relative to world
        playerImage.setX(playerX);
        playerImage.setY(playerY);
    }

    // update collectibles: spawn, move left, check collision
    spawnTimer += delta;
    if (spawnTimer >= spawnInterval) {
        spawnTimer = 0f;
        spawnInterval = spawnIntervalMin + (float)Math.random() * spawnIntervalRange;
        spawnCollectible();
    }

    // move collectibles and check collision
    java.util.Iterator<Image> it = collectibles.iterator();
        while (it.hasNext()) {
        Image c = it.next();
        float cx = c.getX();
        cx -= (normalized * 100f + 120f) * delta; // world scroll speed depends on player speed
        c.setX(cx);
        // remove if off-screen left
        // remove when collectible is far left of the camera view
        com.badlogic.gdx.graphics.Camera cam = stage.getCamera();
        float camLeft = cam.position.x - stage.getViewport().getWorldWidth() * 0.5f;
        if (cx + c.getWidth() < camLeft - 100f) {
            c.remove();
            it.remove();
            continue;
        }
        // collision with player (simple AABB)
                if (playerImage.getX() < c.getX() + c.getWidth() &&
                playerImage.getX() + playerImage.getWidth() > c.getX() &&
                playerImage.getY() < c.getY() + c.getHeight() &&
                playerImage.getY() + playerImage.getHeight() > c.getY()) {
                // contact: apply collectible effect and remove
                c.remove();
                it.remove();
                int mult = 1; // bonus multiplier for jump from touch
                score += 10;
                distance += 2f; // small distance bonus
                // give a jump impulse when touching the collectible
                isJumping = true;
                jumpVelocity = Math.max(jumpVelocity, 600f) + 150f * mult;
                playerAnimTime = 0f;
                    scoreLabel.setText(String.format("Pontos: %d", score));
                    try {
                        // create a floating popup on the UI stage at the world position of the collectible
                        Vector3 worldPos = new Vector3(c.getX() + c.getWidth() * 0.5f, c.getY() + c.getHeight(), 0);
                        stage.getCamera().project(worldPos);
                        Vector2 uiPos = new Vector2(worldPos.x, worldPos.y);
                        uiStage.screenToStageCoordinates(uiPos);
                        Label popup = new Label(String.format("+%d", 10 * mult), game.getSkin());
                        popup.setPosition(uiPos.x - popup.getWidth() * 0.5f, uiPos.y);
                        uiStage.addActor(popup);
                        popup.addAction(Actions.sequence(Actions.parallel(Actions.moveBy(0, 40f, 0.9f, Interpolation.fade), Actions.fadeOut(0.9f)), Actions.removeActor()));
                    } catch (Exception ignored) {}
            }
    }

    // stamina / defeat mechanic
    if (!defeated) {
        // drain when below comfortable cadence, recover when above
        if (normalized < 0.50f) stamina -= 12f * delta; // drain
        else if (normalized > 0.70f) stamina += 18f * delta; // recover faster when pedaling well
        else stamina -= 2f * delta; // slow drain when in-between
        if (stamina > maxStamina) stamina = maxStamina;
        if (stamina < 0f) stamina = 0f;
        if (staminaBar != null) staminaBar.setValue(stamina / maxStamina);
        if (stamina <= 0f) {
            onDefeat();
        }
    } else {
        // when defeated, freeze gameplay updates but keep UI responsive
        Gdx.gl.glClearColor(0.03f, 0.05f, 0.12f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.act(delta);
        stage.draw();
        return;
    }

    updateGameLogic(delta, cadence, normalized);

        // update distance
        float distanceSpeed = normalized * 10f; // meters per second (arbitrary scaling)
        distance += distanceSpeed * delta;
        distanceLabel.setText(String.format("Distância: %.0f m / %.0f m", distance, distanceGoal));
        distanceBar.setValue(Math.min(1f, distance / distanceGoal));

        if (distance >= distanceGoal) {
            finishLevel();
            return;
        }

        if (elapsedTime >= duration) {
            finishLevel();
        }

        Gdx.gl.glClearColor(0.03f, 0.05f, 0.12f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // world then UI (UI uses its own stage so it stays fixed while camera follows player)
        stage.act(delta);
        stage.draw();
        uiStage.act(delta);
        uiStage.draw();
    }

    protected abstract void updateGameLogic(float delta, float cadence, float normalizedSpeed);

    private com.badlogic.gdx.files.FileHandle findBackground(String baseName) {
        try {
            com.badlogic.gdx.files.FileHandle f1 = Gdx.files.local("assets/images/" + baseName + ".png");
            if (f1.exists()) return f1;
            com.badlogic.gdx.files.FileHandle f2 = Gdx.files.local("assets/images/" + baseName + ".jpg");
            if (f2.exists()) return f2;
            com.badlogic.gdx.files.FileHandle f3 = Gdx.files.local("assets/images/" + baseName + ".jpeg");
            if (f3.exists()) return f3;
            // fallback: some uploads used other background filenames, check common alternatives
            if ("bg_near".equals(baseName)) {
                com.badlogic.gdx.files.FileHandle alt = Gdx.files.local("assets/images/backgroundimagelevel1.jpg");
                if (alt.exists()) return alt;
            }
            if ("bg_mid".equals(baseName)) {
                com.badlogic.gdx.files.FileHandle alt = Gdx.files.local("assets/images/backgroundimagelevel2.jpg");
                if (alt.exists()) return alt;
            }
            if ("bg_far".equals(baseName)) {
                com.badlogic.gdx.files.FileHandle alt = Gdx.files.local("assets/images/backgroundlevel3.jpg");
                if (alt.exists()) return alt;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private void spawnCollectible() {
        try {
            com.badlogic.gdx.files.FileHandle fh = Gdx.files.local("assets/images/collectible.png");
            Image c;
            if (fh.exists()) {
                c = new Image(new Texture(fh));
            } else {
                Pixmap p = new Pixmap(24, 24, Pixmap.Format.RGBA8888);
                p.setColor(1f, 0.85f, 0.2f, 1f);
                p.fillCircle(12, 12, 10);
                Texture t = new Texture(p);
                p.dispose();
                c = new Image(t);
            }
            // spawn relative to camera so collectibles always appear ahead of the player
            com.badlogic.gdx.graphics.Camera cam = stage.getCamera();
            float vw = stage.getViewport().getWorldWidth();
            float vh = stage.getViewport().getWorldHeight();
            float camRight = cam.position.x + vw * 0.5f;
            float spawnX = camRight + 40f + (float)Math.random() * 240f;
            float spawnY = groundY + 20f + (float)Math.random() * (vh * 0.3f);
            c.setPosition(spawnX, spawnY);
            // scale collectible modestly
            c.setSize(32f, 32f);
            stage.addActor(c);
            collectibles.add(c);
        } catch (Exception ignored) {
        }
    }

    private void onDefeat() {
        defeated = true;
        // overlay with retry / menu options
        Table overlay = new Table(game.getSkin());
        overlay.setFillParent(true);
        overlay.center();
        try {
            Drawable panel = game.getSkin().getDrawable("glass-panel");
            if (panel != null) overlay.setBackground(panel);
        } catch (Exception ignored) {}

        Label over = new Label("Você perdeu!", game.getSkin(), "title");
        TextButton retry = new TextButton("Tentar novamente", game.getSkin());
        TextButton menu = new TextButton("Menu principal", game.getSkin());

        overlay.add(over).pad(16f).row();
        overlay.add(retry).width(260f).pad(6f).row();
        overlay.add(menu).width(260f).pad(6f).row();

    uiStage.addActor(overlay);

        retry.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (levelNumber == 1) game.setScreen(new Level1Screen(game));
                else if (levelNumber == 2) game.setScreen(new Level2Screen(game));
                else game.setScreen(new Level3Screen(game));
            }
        });

        menu.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new MainMenuScreen(game));
            }
        });
    }

    protected void finishLevel() {
        float avgCadence = (cadenceSamples > 0) ? (sumCadence / cadenceSamples) : 0f;
        int baseScore = (int) (timeInTargetZone * 10f);
        int finalScore = baseScore + score; // include collectible score

        progress.registerLevelResult(levelNumber, finalScore, avgCadence);
        game.setScreen(new StatsScreen(game));
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
        try { uiStage.getViewport().update(width, height, true); } catch (Exception ignored) {}
    }

    @Override
    public void dispose() {
        stage.dispose();
        try { uiStage.dispose(); } catch (Exception ignored) {}
        if (playerTexture != null) playerTexture.dispose();
        try { if (bgFarTex != null) bgFarTex.dispose(); } catch (Exception ignored) {}
        try { if (bgMidTex != null) bgMidTex.dispose(); } catch (Exception ignored) {}
        try { if (bgNearTex != null) bgNearTex.dispose(); } catch (Exception ignored) {}
        for (Texture t : playerFrames) {
            try {
                if (t != null) t.dispose();
            } catch (Exception ignored) {
            }
        }
    }
}
