package br.mackenzie.ui;

import br.mackenzie.game.RehabilitationGame;

public class Level3Screen extends AbstractLevelScreen {

    private float phaseTime;
    private boolean sprintPhase;

    public Level3Screen(RehabilitationGame game) {
        super(game,
              3,
              130f,
              35f,
              60f);
        // make collectibles slightly denser in level 3 for demo
        setSpawnInterval(0.8f, 1.6f);
    }

    @Override
    protected void updateGameLogic(float delta, float cadence, float normalizedSpeed) {
        phaseTime += delta;

        float phaseDuration = sprintPhase ? 20f : 40f;

        if (phaseTime >= phaseDuration) {
            sprintPhase = !sprintPhase;
            phaseTime = 0f;

            if (sprintPhase) {
                targetMinCadence = 45f;
                targetMaxCadence = 65f;
            } else {
                targetMinCadence = 30f;
                targetMaxCadence = 50f;
            }
        }
    }
}
