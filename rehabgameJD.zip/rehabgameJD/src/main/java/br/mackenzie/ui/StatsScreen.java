package br.mackenzie.ui;

import br.mackenzie.game.GameProgress;
import br.mackenzie.game.RehabilitationGame;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class StatsScreen extends ScreenAdapter {

    private final RehabilitationGame game;
    private final Stage stage;

    private TextButton backButton;

    public StatsScreen(RehabilitationGame game) {
        this.game = game;
        this.stage = new Stage(new ScreenViewport());
        createUI();
        Gdx.input.setInputProcessor(stage);
    }

    private void createUI() {
        GameProgress progress = game.getProgress();

        Table root = new Table();
        root.setFillParent(true);
        root.pad(40f);
        // set background if skin provides it
        try {
            Drawable bg = game.getSkin().getDrawable("glass-panel");
            if (bg != null) root.setBackground(bg);
        } catch (Exception ignored) {
        }
        stage.addActor(root);

        Label title = new Label("Estatísticas", game.getSkin(), "title");
        title.setAlignment(Align.center);
        Label subtitle = new Label("Resumo do desempenho nos níveis.", game.getSkin(), "subtitle");
        subtitle.setAlignment(Align.center);

        Label overall = new Label(
                "Maior nível desbloqueado: " + progress.getHighestLevelUnlocked() + " de 3",
                game.getSkin()
        );

        String[] levelNames = {
                "Nível 1 · Aquecimento",
                "Nível 2 · Resistência",
                "Nível 3 · Intervalos"
        };

        Table statsTable = new Table();
        statsTable.defaults().padBottom(6f).left();

        for (int i = 1; i <= 3; i++) {
            int score = progress.getHighScore(i);
            float avgCad = progress.getBestAvgCadence(i);

            String text;
            if (!progress.isLevelUnlocked(i) && i > progress.getHighestLevelUnlocked()) {
                text = levelNames[i - 1] + " · 🔒 Não desbloqueado ainda";
            } else if (score == 0) {
                text = levelNames[i - 1] + " · Nenhuma tentativa registrada";
            } else {
                text = String.format("%s · Melhor pontuação: %d · Cadência média: %.1f rpm",
                        levelNames[i - 1], score, avgCad);
            }

            statsTable.add(new Label(text, game.getSkin())).row();
        }

        backButton = new TextButton("Voltar", game.getSkin());

        backButton.addListener(e -> {
            if (backButton.isPressed()) {
                game.setScreen(new MainMenuScreen(game));
                return true;
            }
            return false;
        });

    root.center();
    root.add(title).padBottom(14f).row();
    root.add(subtitle).padBottom(22f).row();
    root.add(overall).padBottom(22f).row();
    root.add(statsTable).padBottom(28f).row();
    root.add(backButton).width(260f).height(56f).row();
    }

    private void handleKeyboard() {
        if (Gdx.input.isKeyJustPressed(Input.Keys.ENTER) ||
            Gdx.input.isKeyJustPressed(Input.Keys.SPACE) ||
            Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
            game.setScreen(new MainMenuScreen(game));
        }
    }

    @Override
    public void render(float delta) {
        handleKeyboard();

        // slightly brighter background for contrast with UI
        Gdx.gl.glClearColor(0.05f, 0.08f, 0.16f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
