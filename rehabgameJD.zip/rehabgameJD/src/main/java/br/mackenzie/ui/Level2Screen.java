package br.mackenzie.ui;

import br.mackenzie.game.RehabilitationGame;

public class Level2Screen extends AbstractLevelScreen {

    public Level2Screen(RehabilitationGame game) {
        super(game,
              2,
              100f,
              30f,
              50f);
        // make collectibles appear a bit more often in this level for demo
        setSpawnInterval(0.9f, 1.8f);
    }

    @Override
    protected void updateGameLogic(float delta, float cadence, float normalizedSpeed) {
        // Lógica específica do nível 2 (resistência)
    }
}
