package br.mackenzie.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;

import br.mackenzie.ui.MainMenuScreen;

public class RehabilitationGame extends Game {

    private Skin skin;
    private GameProgress progress;
    private BikeInput bikeInput;

    @Override
    public void create() {
        // ensure placeholder assets exist (if the user hasn't provided their own images)
        skin = SkinFactory.createGlassSkin();
        AssetUtils.ensurePlaceholderAssets();
        progress = new GameProgress();

        // Entrada padrão: teclado (dev/teste)
        bikeInput = new KeyboardBikeInput();

        setScreen(new MainMenuScreen(this));
    }

    public Skin getSkin() {
        return skin;
    }

    public GameProgress getProgress() {
        return progress;
    }

    public BikeInput getBikeInput() {
        return bikeInput;
    }

    public void useKeyboardInput() {
        if (!(bikeInput instanceof KeyboardBikeInput)) {
            if (bikeInput != null) bikeInput.dispose();
            bikeInput = new KeyboardBikeInput();
        }
    }

    public void useArduinoInput() {
        if (!(bikeInput instanceof ArduinoBikeInput)) {
            if (bikeInput != null) bikeInput.dispose();
            bikeInput = new ArduinoBikeInput();
        }
    }

    @Override
    public void dispose() {
        super.dispose();
        if (skin != null) skin.dispose();
        if (bikeInput != null) bikeInput.dispose();
    }
}
