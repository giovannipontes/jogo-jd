package br.mackenzie.game;

public interface BikeInput {
    void update(float delta);
    float getCadence();
    float getNormalizedSpeed();
    void dispose();
}
