package br.mackenzie.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Pixmap.Format;
import com.badlogic.gdx.graphics.PixmapIO;

import java.io.File;

/**
 * Utility to generate simple placeholder assets (PNGs) at runtime if missing.
 * This allows the game to run with visuals even when no external images are provided.
 */
public class AssetUtils {

    public static void ensurePlaceholderAssets() {
        try {
            File imagesDir = new File("assets/images");
            if (!imagesDir.exists()) {
                imagesDir.mkdirs();
            }

            createIfMissing("assets/images/player_run.png", 96, 96, (p) -> {
                // simple two-tone player rectangle with a 'head'
                p.setColor(0.12f, 0.6f, 0.95f, 1f);
                p.fillRectangle(8, 16, 80, 56);
                p.setColor(1f, 0.9f, 0.6f, 1f);
                p.fillCircle(48, 70, 10);
            });

            createIfMissing("assets/images/bg_far.png", 1280, 360, (p) -> {
                // sky gradient-ish
                p.setColor(0.05f, 0.08f, 0.2f, 1f);
                p.fill();
            });

            createIfMissing("assets/images/bg_mid.png", 1280, 360, (p) -> {
                // simple hills (approximated with circles)
                p.setColor(0.08f, 0.15f, 0.3f, 1f);
                p.fill();
                p.setColor(0.12f, 0.4f, 0.25f, 1f);
                p.fillCircle(300, 120, 260);
                p.fillCircle(800, 110, 300);
            });

            createIfMissing("assets/images/bg_near.png", 1280, 200, (p) -> {
                // ground strip
                p.setColor(0.06f, 0.04f, 0.02f, 1f);
                p.fill();
                p.setColor(0.18f, 0.12f, 0.05f, 1f);
                for (int x = 0; x < p.getWidth(); x += 40) {
                    p.fillRectangle(x, 0, 20, 40);
                }
            });
        } catch (Exception e) {
            System.err.println("AssetUtils: failed to create placeholder assets: " + e.getMessage());
        }
    }

    private interface PixmapPainter {
        void paint(Pixmap p);
    }

    private static void createIfMissing(String path, int w, int h, PixmapPainter painter) {
        File f = new File(path);
        if (f.exists()) return;

        Pixmap pixmap = new Pixmap(w, h, Format.RGBA8888);
        try {
            painter.paint(pixmap);
            FileHandle handle = Gdx.files.local(path);
            PixmapIO.writePNG(handle, pixmap);
            System.out.println("AssetUtils: wrote placeholder " + path);
        } catch (Exception e) {
            System.err.println("AssetUtils: error writing " + path + " -> " + e.getMessage());
        } finally {
            pixmap.dispose();
        }
    }
}
