package br.mackenzie.game;

public class GameProgress {

    private int highestLevelUnlocked = 1;
    private int[] bestScores = new int[3];
    private float[] bestAvgCadence = new float[3];

    public int getHighestLevelUnlocked() {
        return highestLevelUnlocked;
    }

    public void unlockLevel(int level) {
        if (level > highestLevelUnlocked && level <= 3) {
            highestLevelUnlocked = level;
        }
    }

    public boolean isLevelUnlocked(int level) {
        return level <= highestLevelUnlocked;
    }

    public int getHighScore(int level) {
        if (level < 1 || level > 3) return 0;
        return bestScores[level - 1];
    }

    public float getBestAvgCadence(int level) {
        if (level < 1 || level > 3) return 0f;
        return bestAvgCadence[level - 1];
    }

    public void registerLevelResult(int level, int score, float avgCadence) {
        if (level < 1 || level > 3) return;
        if (score > bestScores[level - 1]) {
            bestScores[level - 1] = score;
            bestAvgCadence[level - 1] = avgCadence;
        }
        if (score > 0 && level < 3) {
            unlockLevel(level + 1);
        }
    }
}
