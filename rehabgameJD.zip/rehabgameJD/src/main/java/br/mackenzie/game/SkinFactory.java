package br.mackenzie.game;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ProgressBar;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;

public class SkinFactory {

    public static Skin createGlassSkin() {
        Skin skin = new Skin();

    BitmapFont defaultFont = new BitmapFont();
    // keep a base font and create scaled variants for titles and buttons
    BitmapFont titleFont = new BitmapFont();
    // larger, more impactful title font
    titleFont.getData().setScale(3.0f);
    BitmapFont buttonFont = new BitmapFont();
    buttonFont.getData().setScale(1.4f);
    BitmapFont defaultScaled = new BitmapFont();
    defaultScaled.getData().setScale(1.0f);
    skin.add("default-font", defaultScaled);
    skin.add("title-font", titleFont);
    skin.add("button-font", buttonFont);

        Pixmap pixmap = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
        pixmap.setColor(Color.WHITE);
        pixmap.fill();
        Texture whiteTex = new Texture(pixmap);
        pixmap.dispose();
        skin.add("white", whiteTex);

        TextureRegionDrawable base = new TextureRegionDrawable(new TextureRegion(whiteTex));

    // Slightly brighter glass so UI reads better on dark backgrounds
    Drawable glassPanel = base.tint(new Color(1f, 1f, 1f, 0.20f));
    Drawable glassHighlight = base.tint(new Color(1f, 1f, 1f, 0.40f));
        Drawable accentBg = base.tint(new Color(0.2f, 0.7f, 1f, 0.85f));

        skin.add("glass-panel", glassPanel);
        skin.add("glass-highlight", glassHighlight);
        skin.add("accent-bg", accentBg);

        // Label default
    Label.LabelStyle labelStyle = new Label.LabelStyle();
    labelStyle.font = defaultScaled;
    labelStyle.fontColor = Color.valueOf("E8EEF8");
    skin.add("default", labelStyle);

    Label.LabelStyle titleStyle = new Label.LabelStyle();
    titleStyle.font = titleFont;
    titleStyle.fontColor = Color.WHITE;
    skin.add("title", titleStyle);

    Label.LabelStyle subtitleStyle = new Label.LabelStyle();
    subtitleStyle.font = defaultScaled;
    subtitleStyle.fontColor = Color.valueOf("C9D7EC");
    skin.add("subtitle", subtitleStyle);

        // TextButton default
    TextButton.TextButtonStyle btnStyle = new TextButton.TextButtonStyle();
    btnStyle.font = buttonFont;
        btnStyle.up = glassPanel;
        btnStyle.over = glassHighlight;
        btnStyle.down = accentBg;
    btnStyle.fontColor = Color.valueOf("F6FBFF");
        btnStyle.overFontColor = Color.WHITE;
        btnStyle.downFontColor = Color.WHITE;
        skin.add("default", btnStyle);

        // TextButton danger
    TextButton.TextButtonStyle dangerStyle = new TextButton.TextButtonStyle();
    dangerStyle.font = buttonFont;
        dangerStyle.up = glassPanel;
        dangerStyle.over = glassHighlight;
        dangerStyle.down = base.tint(new Color(1f, 0.3f, 0.3f, 0.9f));
        dangerStyle.fontColor = Color.valueOf("F3B0B0");
        dangerStyle.overFontColor = Color.WHITE;
        dangerStyle.downFontColor = Color.WHITE;
        skin.add("danger", dangerStyle);

        // TextField
    TextField.TextFieldStyle tfStyle = new TextField.TextFieldStyle();
    tfStyle.font = defaultScaled;
    tfStyle.fontColor = Color.WHITE;
        tfStyle.background = glassPanel;
        tfStyle.cursor = accentBg;
        tfStyle.selection = accentBg;
        skin.add("default", tfStyle);

        // ProgressBar
        ProgressBar.ProgressBarStyle pbStyle = new ProgressBar.ProgressBarStyle();
        pbStyle.background = glassPanel;
        pbStyle.knobBefore = accentBg;
        pbStyle.knob = accentBg;
        skin.add("default-horizontal", pbStyle);

        return skin;
    }
}
