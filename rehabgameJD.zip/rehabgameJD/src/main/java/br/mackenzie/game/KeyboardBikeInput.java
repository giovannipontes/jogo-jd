package br.mackenzie.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;

public class KeyboardBikeInput implements BikeInput {

    private float cadence;
    private float maxCadence = 80f;
    private float accel = 40f;

    @Override
    public void update(float delta) {
        if (Gdx.input.isKeyPressed(Input.Keys.W) || Gdx.input.isKeyPressed(Input.Keys.UP)) {
            cadence += accel * delta;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.S) || Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
            cadence -= accel * delta;
        }

        cadence -= 10f * delta; // atrito

        if (cadence < 0) cadence = 0;
        if (cadence > maxCadence) cadence = maxCadence;
    }

    @Override
    public float getCadence() {
        return cadence;
    }

    @Override
    public float getNormalizedSpeed() {
        return maxCadence == 0 ? 0 : cadence / maxCadence;
    }

    @Override
    public void dispose() {
    }
}
