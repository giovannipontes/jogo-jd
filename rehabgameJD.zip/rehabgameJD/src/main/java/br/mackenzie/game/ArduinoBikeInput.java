package br.mackenzie.game;

import com.fazecast.jSerialComm.SerialPort;
import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * ArduinoBikeInput reads lines from a serial port and expects the Arduino to
 * send either plain numeric RPM values (e.g. "34.5") or labeled values
 * (e.g. "RPM:34.5").
 *
 * Usage: specify the serial port via system property -Darduino.port=/dev/ttyXXX
 * or environment variable ARDUINO_PORT. If none provided, the implementation
 * will try to auto-detect common Arduino/USB serial ports.
 */
public class ArduinoBikeInput implements BikeInput {

    private volatile float cadence = 0f;
    private float maxCadence = 80f;

    private SerialPort serialPort;
    private Thread readerThread;
    private volatile boolean running = false;

    public ArduinoBikeInput() {
        String portName = System.getProperty("arduino.port");
        if (portName == null || portName.isEmpty()) {
            portName = System.getenv("ARDUINO_PORT");
        }

        if (portName == null || portName.isEmpty()) {
            // try auto-detect
            SerialPort[] ports = SerialPort.getCommPorts();
            for (SerialPort p : ports) {
                String desc = (p.getDescriptivePortName() == null) ? "" : p.getDescriptivePortName().toLowerCase();
                String sys = (p.getSystemPortName() == null) ? "" : p.getSystemPortName().toLowerCase();
                if (desc.contains("arduino") || sys.contains("usbmodem") || sys.contains("usbserial") || desc.contains("usb")) {
                    portName = p.getSystemPortName();
                    break;
                }
            }
        }

        if (portName == null || portName.isEmpty()) {
            System.err.println("ArduinoBikeInput: no serial port specified or detected. Set -Darduino.port=/dev/ttyXXX or ARDUINO_PORT.");
            return;
        }

        serialPort = SerialPort.getCommPort(portName);
        serialPort.setBaudRate(9600);
        serialPort.setComPortTimeouts(SerialPort.TIMEOUT_READ_SEMI_BLOCKING, 1000, 0);

        if (!serialPort.openPort()) {
            System.err.println("ArduinoBikeInput: failed to open port " + portName);
            serialPort = null;
            return;
        }

        running = true;
        readerThread = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(serialPort.getInputStream()))) {
                String line;
                while (running && (line = r.readLine()) != null) {
                    parseLine(line);
                }
            } catch (Exception e) {
                System.err.println("ArduinoBikeInput: serial read error: " + e.getMessage());
            }
        }, "ArduinoBikeInput-Reader");
        readerThread.setDaemon(true);
        readerThread.start();
    }

    private void parseLine(String line) {
        if (line == null) return;
        String s = line.trim();
        if (s.isEmpty()) return;

        // allow formats like "RPM:34.5", "34.5", "cadence=34.5"
        s = s.replaceAll("(?i)rpm", "");
        s = s.replaceAll("[^0-9.,+-]", " ").trim();
        s = s.replace(',', '.');

        java.util.regex.Matcher m = java.util.regex.Pattern.compile("([-+]?[0-9]*\\.?[0-9]+)").matcher(s);
        if (m.find()) {
            try {
                float v = Float.parseFloat(m.group(1));
                if (v >= 0 && v <= 1000) {
                    cadence = v;
                }
            } catch (NumberFormatException ignored) {
            }
        }
    }

    @Override
    public void update(float delta) {
        // cadence is updated asynchronously by the reader thread
    }

    @Override
    public float getCadence() {
        return cadence;
    }

    @Override
    public float getNormalizedSpeed() {
        return maxCadence == 0 ? 0 : cadence / maxCadence;
    }

    @Override
    public void dispose() {
        running = false;
        try {
            if (readerThread != null) readerThread.join(300);
        } catch (InterruptedException ignored) {
        }
        if (serialPort != null && serialPort.isOpen()) {
            serialPort.closePort();
        }
    }
}

