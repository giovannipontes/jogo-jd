# RehabGameJD — Como rodar (desktop)

Projeto libGDX (single-module) com launcher desktop minimal para desenvolvimento e teste.

Pré-requisitos
- Java 8+ instalado
- Gradle instalado (ou gere o wrapper localmente com `gradle wrapper`)

Rodando
1. Na raiz do projeto (onde está `build.gradle`) execute:

```
gradle run
```

ou, se preferir criar o wrapper:

```
gradle wrapper
./gradlew run
```

Notas
- O código fonte principal já existe no diretório raiz e o launcher fica em `src/main/java/br/mackenzie/desktop/DesktopLauncher.java`.
- A entrada padrão é o `KeyboardBikeInput` (teclas W/S ou UP/DOWN para controlar a cadência de teste). No menu você pode alternar para `ArduinoBikeInput` que ainda precisa implementar leitura serial.
 - O código fonte principal já existe no diretório raiz e o launcher fica em `src/main/java/br/mackenzie/desktop/DesktopLauncher.java`.
 - A entrada padrão é o `KeyboardBikeInput` (teclas W/S ou UP/DOWN para controlar a cadência de teste). No menu você pode alternar para `ArduinoBikeInput` que agora implementa leitura serial via jSerialComm.

Arduino / IoT (como usar)
- A integração serial usa a biblioteca `com.fazecast:jSerialComm`.
- Formato aceito (flexível): linhas com um número indicando RPM. Exemplos válidos que o leitor aceitará:
	- "34.5"
	- "RPM:34.5"
	- "cadence=34.5"

Placeholder assets gerados automaticamente
- Se não existir a pasta `assets/images`, o jogo agora gera automaticamente imagens placeholder (player_run.png, bg_far.png, bg_mid.png, bg_near.png) na primeira execução. Assim você já consegue ver o visual sem enviar imagens.

Substituir por imagens próprias
- Para usar imagens próprias, coloque-as em `assets/images/` com os nomes sugeridos (veja a seção "Recomendações de assets" no README). O jogo irá preferir arquivos presentes em `assets/images` em vez dos placeholders.

Como apontar a porta serial
- Defina a porta via variável de ambiente ARDUINO_PORT ou via propriedade do sistema `-Darduino.port=/dev/ttyXXX`.
	Exemplo (macOS):

```bash
ARDUINO_PORT=/dev/tty.usbmodem14101 gradle run
# ou
gradle -Darduino.port=/dev/tty.usbmodem14101 run
```

O comportamento se nenhuma porta for encontrada
- O código tenta auto-detectar portas com nomes comuns (contendo "arduino", "usbmodem", "usbserial" etc.).
- Se não encontrar nenhuma porta, a entrada Arduino permanece inativa e a cadência fica em 0 (o jogo continua usando a entrada de teclado por padrão).

Criar o Gradle Wrapper (recomendado)
- Se preferir executar com `./gradlew run` sem instalar Gradle globalmente, gere o wrapper no seu sistema (é necessário Gradle uma vez para gerá-lo):

```bash
# instale gradle (Homebrew):
brew install gradle
# na raiz do projeto:
gradle wrapper
./gradlew run
```

Se quiser que eu adicione os arquivos do wrapper ao repositório para você, posso fazer isso (o wrapper inclui scripts e um pequeno JAR). Diga se quer que eu gere e adicione esses arquivos.
