Coloque aqui as imagens de fundo e do personagem fornecidas pelo usuário.

Nomes esperados pelo código (padrão):
- assets/images/bg_far.png   <- camada mais distante (ex: espaço/vermelho)
- assets/images/bg_mid.png   <- camada do meio (ex: montanhas azuis)
- assets/images/bg_near.png  <- camada mais próxima (ex: chão/grama/pedra)

Para o personagem, coloque os frames do sprite aqui, nomeados de forma que ordenem lexicograficamente:
- assets/images/player/run_000.png
- assets/images/player/run_001.png
- assets/images/player/run_002.png
  ... e assim por diante.

Comandos úteis (execute no diretório do projeto):

# crie diretórios (já criados por mim):
# mkdir -p assets/images/player

# copie os arquivos locais para o projeto (substitua os caminhos de origem):
# cp /caminho/para/fundo1.png assets/images/bg_near.png
# cp /caminho/para/fundo2.png assets/images/bg_mid.png
# cp /caminho/para/fundo3.png assets/images/bg_far.png

# copie os frames do personagem (exemplo):
# cp /caminho/para/frame1.png assets/images/player/run_000.png
# cp /caminho/para/frame2.png assets/images/player/run_001.png
# cp /caminho/para/frame3.png assets/images/player/run_002.png

# depois rode (use Rosetta se tiver erro de natives no Apple Silicon):
# ./gradlew run
# ou
# arch -x86_64 ./gradlew run

Se preferir, eu posso copiar os anexos que você enviou diretamente para essas pastas se você autorizar — porém eu não tenho acesso direto aos arquivos binários dos anexos fora do workspace; se você quiser que eu os coloque, arraste/importe os arquivos para a raiz do workspace (por exemplo via VS Code arrastar) e me avise os nomes, ou cole aqui os caminhos locais onde os arquivos estão no seu sistema para que eu possa rodar comandos de cópia se você me autorizar a executar comandos no terminal.